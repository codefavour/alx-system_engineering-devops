This directory containes all basic shell I/O redirections commands
